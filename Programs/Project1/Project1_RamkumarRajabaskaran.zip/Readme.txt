Name :- Ramkumar Rajabaskaran
ID:- 85241493
Part A has 2 inputs, one input file and one output file.
Part B has 3 inputs, two input files and one output file.
Part C also has 3 inputs, two input files and one output file.