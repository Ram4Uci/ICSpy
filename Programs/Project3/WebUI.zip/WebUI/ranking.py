import index
import os
import string
import json
from urlparse import urlparse
from flask import Flask, render_template,redirect,request

from bs4 import BeautifulSoup
from lxml.html import soupparser
import nltk, re, pprint
import magic
from pprint import pprint
from nltk import word_tokenize          
from nltk.stem.porter import PorterStemmer
from pymongo import MongoClient
import math
from nltk.corpus import stopwords
from collections import Counter


client = MongoClient()
db = client.new_index
fancy_db = client.fancy_index
stemmer = PorterStemmer()
query = ""
url_list = []

PR=dict()
with open("../Indexer/pr.json") as prj:
    PR = json.load(prj)
json_data = dict()    
with open("../Indexer/bookkeeping.json") as jsonf:
    json_data = json.load(jsonf)

app = Flask(__name__)

@app.route('/query', methods = ['POST'])
def signup():
    global query
    global url_list
    global file_list
    url_list = []
    query= request.form['query']
    file_list = find_best_ranked(query)
    loadjson(file_list)
    #print file_list
    print("The Query is :- " + query + "\n")
    return redirect('/results')

@app.route('/')
def hello_world():
    return render_template('index.jsp')

@app.route('/results')
def results():
    global file_list
    global url_list
    author = "Ramkumar"
    name = "Yashaswini"
    return render_template('results.html', title=author,url_list = url_list)



def docList(word):
	word_list = list()
	word_list.append(word.lower())
	letter = index.getLetter(word)
	index_file = index.getIndexName(letter)
	my_collection = db[index_file]
	result = my_collection.find({"word": word}).limit(1)
	res = list(result)
	# print "res:", res
	doc_result = list()

	if res: 
		# print "index: ", res[0]['index']
		#print "word: ", res[0]['word']
		#print "df: ", res[0]['df']

		for document in res[0]['index']:
			doc_result.append((document, res[0]['index'][document][1]))

		ret_val = res[0]['index']

	else:
		ret_val = {}
	return doc_result


def get_key_docList(word):
	word_list = list()
	word_list.append(word.lower())
	
	my_collection = db["title_index"]
	# print "\n\n",word, "\n\n"
	result = my_collection.find({"word": word}).limit(1)
	res = list(result)
	# print "res:", res
	doc_result = list()

	if res: 
		# print "index: ", res[0]['index']
		#print "word: ", res[0]['word']
		#print "idf: ", res[0]['idf']

		for document in res[0]['index']:
			doc_result.append((document, res[0]['index'][document]))

		# ret_val = res[0]['index']

	
	return doc_result
    
def get_base_docList(word):
	word_list = list()
	word_list.append(word.lower())
	
	my_collection = fancy_db["tag_index"]
	# print "\n\n",word, "\n\n"
	result = my_collection.find({"word": word}).limit(1)
	res = list(result)
	# print "res:", res
	doc_result = list()

	if res: 
		# print "index: ", res[0]['index']
		#print "word: ", res[0]['word']
		#print "idf: ", res[0]['idf']

		for document in res[0]['index']:
			doc_result.append((document, res[0]['index'][document]))

		# ret_val = res[0]['index']

	
	return doc_result

def rank_results(results):
	pass

def process_query(query):
	stop_words = set(stopwords.words('english'))
	query = re.sub(r'[\W_]+', ' ', query)
	words = [word.strip().lower() for word in query.split(" ") if word not in stop_words]
	# print words
	wordDict = dict()
	intersection = set()
	results = list()
	unionDict = dict()

	for word in words:
            word = stem_word(word, stemmer)
            # print word
            wordDict[word] = docList(word) #Should get back a list of form : [(docID1, tf-IDF1), (docID2, tf-IDF2).....]
            # print wordDict[word]
            for doc in wordDict[word]:
		unionDict[doc[0]] = unionDict.get(doc[0], 0)
		unionDict[doc[0]] += doc[1]	#Add Tf-idf values for that doc
        #print unionDict
        #print "\n\n\nUnionDict",query,"\n\n\n"
        #raw_input()
	return [(x, unionDict[x]) for x in sorted(unionDict, key = unionDict.get, reverse = True)]



def process_key_query(query):
	stop_words = set(stopwords.words('english'))
	query = re.sub(r'[\W_]+', ' ', query)
	words = [word.strip().lower() for word in query.split(" ") if word not in stop_words]
	# print words
	wordDict = dict()
	intersection = set()
	results = list()
	unionDict = dict()

        for word in words:
            word = stem_word(word, stemmer)
	    # print word
            wordDict[word] = get_key_docList(word) #Should get back a list of form : [(docID1, tf-IDF1), (docID2, tf-IDF2).....]
            # print wordDict[word]
            for doc in wordDict[word]:
                unionDict[doc[0]] = unionDict.get(doc[0], 0)
		unionDict[doc[0]] += doc[1]	#Add Tf-idf values for that doc
        #pprint (unionDict)
        #raw_input()
	return [(x, unionDict[x]) for x in sorted(unionDict, key = unionDict.get, reverse = True)]
def process_base_query(query):
	stop_words = set(stopwords.words('english'))
	query = re.sub(r'[\W_]+', ' ', query)
	words = [word.strip().lower() for word in query.split(" ") if word not in stop_words]
	# print words
	wordDict = dict()
	intersection = set()
	results = list()
        unionDict = dict()


	for word in words:
            word = stem_word(word, stemmer)
            # print word
            wordDict[word] = get_base_docList(word) #Should get back a list of form : [(docID1, tf-IDF1), (docID2, tf-IDF2).....]
            # print wordDict[word]
            for doc in wordDict[word]:
                
		unionDict[doc[0]] = unionDict.get(doc[0], 0)
		unionDict[doc[0]] += doc[1]	#Add Tf-idf values for that doc
       
	return [(x, unionDict[x]) for x in sorted(unionDict, key = unionDict.get, reverse = True)]

def compare(x, y):
	if x[1] > y[1]:
		return -1

	elif x[1] == y[1]:
		return 0

	return 1

def stem_word(word, stemmer):

	try:
		stemmed = stemmer.stem(word)
		
	except UnicodeDecodeError:
		pass
	
	# print "stemmed: ", stemmed
	return stemmed
def combine(result, key_result, base_result):
	tf_idf = 0
	alpha = 15
	gamma = 15
	beta = 60
	delta = 10
	global PR
	global json_data
	tf_idf_res = dict()
	for doc in result:
                urls = json_data.get(doc,"Error")
                urls = urls.strip().rstrip('/')
                if urls == "Error":
                    continue
                pr_score = PR.get(urls,0)
                #print pr_score
                #raw_input()
		tf_idf = alpha * result[doc] + beta * key_result.get(doc, 0) + gamma * base_result.get(doc,0) + delta*pr_score
		tf_idf_res[doc] = tf_idf
	
	for doc in key_result:
		if doc not in tf_idf_res:
                        urls = json_data.get(doc,"Error")
                        if urls == "Error":
                            continue
                        urlp = urlparse(urls)
                        urls = urlp.netloc + '/' + urlp.path
                        pr_score = PR.get(urls,0)
			tf_idf_res[doc] = beta * key_result.get(doc, 0) + delta * pr_score

	for x in sorted(tf_idf_res,key = tf_idf_res.get, reverse = True):
            #pprint(str(x) + " " + str(tf_idf_res[x]))
            pass


	return [x for x in sorted(tf_idf_res, key = tf_idf_res.get, reverse = True)][:100]


def find_best_ranked(query):
	result = process_query(query)
	key_result = process_key_query(query)
        base_result = process_base_query(query)
	# print dict(result)
	# print "-----------------" * 10
	# print dict(fancy_result)
	#pprint(result)
	#print "\n\n\n"
	#pprint(key_result)
	#print "\n\n\n"
	#pprint (base_result)
	#print "\n\n\n"
	return combine(dict(result), dict(key_result), dict(base_result))

def loadjson(file_list):
        global url_list
        global json_data
        for f in file_list:
            url_dict={}
            urls = json_data.get(f,"Does not exist")
            if(urls != "Does not exist"):
                urls = "https://" + urls
                #print urls
                url_list.append(urls)
                #print f+ " " +urls , "\n"



if __name__ == '__main__':

        app.run()
	# result = docList('retrieval')
	# print result
	# query = raw_input()
	# result = process_query(query)
	# print result
